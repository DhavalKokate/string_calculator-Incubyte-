package calculator;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

class StringCalculatorShould {
	private  StringCalculator stringCalculator = new StringCalculator();
    @Test
    void empty_string_should_return_0() {     
        assertEquals(0, stringCalculator.add(""));
    }

    @Test
    void string_with_single_number_should_return_number_as_int() {
        assertEquals(1, stringCalculator.add("1"));
    }
    
    @Test
    void string_with_comma_as_delimeter() {
        assertEquals(3, stringCalculator.add("1,2"));
    }
    
    @Test
    void string_with_comma_or_newline_as_delimeter_with_tree_inputs() {
        assertEquals(5, stringCalculator.add("1,2\n2"));
    }
    
    @Test
    void string_with_comma_or_newline_as_delimeter_with_multiple_inputs() {
        assertEquals(7, stringCalculator.add("1,2\n2,2"));
    }
    
    @org.junit.Test(expected = IllegalArgumentException.class)
    public void negativeInputReturnExcetion()
    {
    	stringCalculator.add("-1");
    }
    @Test
    void ignoreTheNumberGreaterThan1000() {
        assertEquals(7, stringCalculator.add("1001,2"));
    }
    
    @Test
    void inputWithSpecifiedDelimiter() {
        assertEquals(7, stringCalculator.add("//***\n1***2***3"));
    }
}
